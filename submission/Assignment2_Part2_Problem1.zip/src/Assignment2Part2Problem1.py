"""
Assignment2Part
Boris Bojanov
AUID: 3608550

Comp457 Assignment2 Part2, Problem1: SentimentAnalysisWithRNN_LSTM

Assignment 2 coding problems in part 2 of assignment
Measuring Sentiment Analysis with RNN/LSTM

We need pass text data through an text embedding layer, feed those embeddings sequentially into an RNN layer, 
    and then finally use a fully connected linear layer to output a classification probability
    Input Text -> Embedding -> RNN -> Fully Connected -> Output (2 Class prediction)

1. Data Preperation (prepareData): convert tokens to integer sequences using a vocabulary, and pad sequences to the same length.
2. Model architecture (class RNN): The model architecture has: 
        an embedding layer, 
        an RNN layer, 
        a fully connected output layer with sigmoid activation (map output to 0 or 1)
3. TrainModel: 
        Useing the training set,
        log the training process using binary cross-entropy loss, 
        apply the Adam optimizer. 
        
        Fixed number of epochs (5-10) and record the loss and accuracy

4. (evaluateModel): Evaluate the model on the test set and 
    report the accuracy, confusion matrix, precision, recall, and F1 score.

5. Repeat (RNN, LSTM, GRU): Replace RNN with LSTM and GRU and compare performance with different embedding sizes and sequence lengths. Also, repeat the experiment using a pre-trained embedding (GloVe) and compare the performance.


IMDB dataset for sentiment analysis: https://ai.stanford.edu/~amaas/data/sentiment/
    This dataset ships with Pytorch-NLP, installed using `pip3 install pytorch-nlp`.
    
Dataset Structure:
    SPLIT	Reviews	Labels
    Train	25,000	balanced pos / neg
    Test	25,000	balanced pos / neg
    Unsupervised	50,000	 unlabeled

    Fields
    text: raw movie review (string)
    label: 0 = negative, 1 = positive (boolean)


Initial project setup follows instructions from two tutorials:
    geeeksforgeeks:  https://www.geeksforgeeks.org/deep-learning/how-to-use-pytorch-for-sentiment-analysis-on-textual-data/
    kaggle: https://www.kaggle.com/code/jeslyjoji/sentiment-analysis-using-rnn-in-pytorch

Pytorch Documentation
    torchnlp documentation: https://pytorchnlp.readthedocs.io/en/latest/

Perplexity:
    We use perplexity as a metric to evaluate the performance of our RNN/LSTM model for sentiment analysis.
    perplexity of sequence X:
    - Perplexity = 1: Perfect model (always predicts the right token with probability 1)
    - Perplexity = ∞ (infinity): Worst case (assigns probability 0 to true tokens)
    - Perplexity = |vocabulary| (size of vocabulary): Baseline (uniform distribution over all words)
    - Lower perplexity = better model

Problem Observations:
    Poor memory retention

    
Comp457 Assignment2 Part2, Problem2: WordMeaningSensingWithRNN_LSTM
    Pro: Long Short-Term Memory (LSTM) has better memory retention.

"""
from pathlib import Path

import math
import random
from typing import Any
import matplotlib.pyplot as plt

# Model
import torch 
from torch import nn

# Data Pipeline
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

# Tokenize Data
import re
from collections import Counter

import os
import glob
import json
import time
import argparse
from functools import lru_cache

from torchnlp.download import download_file_maybe_extract

# Live training curves + evaluation charts (see model_eval.py)
from model_eval import fit, evaluateAndPlot, evaluateLoader
DOC_FIGS_NAME ="assignment2part1"
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
MODEL_PATH = Path(__file__).resolve().parent.parent / "model.pth"
GLOVE_DIR = DATA_DIR / "glove"                   # glove.6B.<dim>d.txt from https://nlp.stanford.edu/projects/glove/
SWEEP_DIR = DATA_DIR / "figures" / "sweep"       # curves, history and results.json of the task 5 experiments

# Hyperparameters
VOCAB_SIZE = 1000       # Size of each dictionary / vocabulary
EMBEDDING_DIM = 100     # Dimension of word vectors
HIDDEN_DIM = 128        # Dimensions of RNN internal hidden state
BATCH_SIZE = 32
EPOCHS = 5

MAX_LEN = 200
PAD, UNK = 0, 1
SEED = 0
TRAIN_LOSSES, TEST_LOSSES, TEST_ACCURACIES = [],[],[]


def get_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def makeEmbedding(vocab_size, embedding_dim, pretrained=None, freeze=False) -> nn.Embedding:
    """Randomly initialised embedding, or one that starts from a pretrained [vocab_size, embedding_dim] matrix."""
    if pretrained is None:
        return nn.Embedding(vocab_size, embedding_dim, padding_idx=PAD)
    return nn.Embedding.from_pretrained(pretrained.clone(), freeze=freeze, padding_idx=PAD)


class RNN(nn.Module):
    """ A sinmple RNN architecture
        an embedding layer, 
        an RNN layer, 
        a fully connected output layer with *sigmoid activation*
    Keyword arguments:
    argument -- description
    Return: return_description
    """
    
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim=1, num_layers=1, pretrained=None, freeze=False):
        super().__init__()

        # 1. Embedding Layer: Maps word indices to dense vectors (embeddings)
        #    pretrained = [vocab_size, embedding_dim] tensor (GloVe) to start from, freeze = keep it fixed
        self.embedding = makeEmbedding(vocab_size, embedding_dim, pretrained, freeze)
        
        """
        2. RNN Layer: Processes sequences of text
            Output: tuple(output, h_n)
                    N ={} & text{batch size} \\
                    L ={} & text{sequence length} \\
                    D ={} & 2 text{ if bidirectional=True otherwise } 1 \\
                    H_{in} ={} & text{input_size} \\
                    H_{out} ={} & text{hidden_size}
    
               output: tensor of shape (L, D * H_{out})
               h_n: tensor of shape (D * num_layers, H_{out})
        """
        # Added batch_first=True so hidden[-1] stays correct
        self.rnn = nn.RNN(embedding_dim, hidden_dim, batch_first=True)

        # 3. Fully Connected Layer: Maps the final hidden state to output dimension
        #   For binary classification set output_dim = 1 (1 output neuron)
        self.fc = nn.Linear(hidden_dim, output_dim)
        
        self.sigmoid = nn.Sigmoid()

        self.output_layer = self.fc
        
    def forward(self, text):
        # text shape: [batch_size, sequence_length]
        embedded = self.embedding(text) # shape: [batch_size, sequence_length, embedding_dim]
        
        # rnn_out: the hidden states for each time step
        # hidden: has final hidden state for the sequence
        rnn_out, hidden = self.rnn(embedded)

        # Take the final hidden state to pass to the linear classifier
        #   In multi-layer RNN, "hidden[-1]" extracts the final state of the top-most (topmost) layer 
        final_hidden = hidden[-1, :, :]

        # Apply the linear fully connected layer
        x = self.fc(final_hidden)
        # Apply sigmoid to strictly enforce 0 or 1
        out = self.sigmoid(x)
        return out

class LSTM(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim=1, num_layers=1, pretrained=None, freeze=False):
        super().__init__()
        self.embedding = makeEmbedding(vocab_size, embedding_dim, pretrained, freeze)
        """
                N ={} & text{batch size} \\
                L ={} & text{sequence length} \\
                D ={} & 2 text{ if bidirectional=True otherwise } 1 \\
                H_{in} ={} & text{input_size} \\
                H_{cell} ={} & text{hidden_size} \\
                H_{out} ={} & text{proj_size if } text{proj_size}>0 text{ otherwise hidden_size} \\
        Outputs: output, (h_n, c_n)
                output: tensor of shape `(L, D * H_{out})` for unbatched input,
                  `(L, N, D * H_{out})` when ``batch_first=False`` or
                  `(N, L, D * H_{out})` when ``batch_first=True`` containing the output features
                  `(h_t)` from the last layer of the LSTM, for each `t`. If a
                  :class:`torch.nn.utils.rnn.PackedSequence` has been given as the input, the output
                  will also be a packed sequence. When ``bidirectional=True``, `output` will contain
                  a concatenation of the forward and reverse hidden states at each time step in the sequence.
                h_n: tensor of shape `(D * text{num_layers}, H_{out})` for unbatched input or
                  `(D * text{num_layers}, N, H_{out})` containing the
                  final hidden state for each element in the sequence. When ``bidirectional=True``,
                  `h_n` will contain a concatenation of the final forward and reverse hidden states, respectively.
                c_n: tensor of shape `(D * text{num_layers}, H_{cell})` for unbatched input or
                  `(D * text{num_layers}, N, H_{cell})` containing the
                  final cell state for each element in the sequence. When ``bidirectional=True``,
                  `c_n` will contain a concatenation of the final forward and reverse cell states, respectively.

        """
        # nn.LSTM returns: output, (h_n, c_n)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)
        self.sigmoid = nn.Sigmoid()

    def forward(self, text):
        embedded = self.embedding(text)
        lstm, (hidden, _) = self.lstm(embedded)
        return self.sigmoid(self.fc(hidden[-1]))

class GRU(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim=1, num_layers=1, pretrained=None, freeze=False):
        super().__init__()
        self.embedding = makeEmbedding(vocab_size, embedding_dim, pretrained, freeze)
        self.gru = nn.GRU(embedding_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)
        self.sigmoid = nn.Sigmoid()

    def forward(self, text):
        embedded = self.embedding(text)
        _, hidden = self.gru(embedded)
        return self.sigmoid(self.fc(hidden[-1]))

# Plot the data
def curvePlotter(train_losses: list, test_losses: list, test_accs: list):
    """
    Left: train_losses and test_losses — two lines, same axes (both are loss, same units, so they share a scaler).
    Right: test_accs — its own axes.
    """
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(train_losses, label="train loss")
    ax.plot(test_losses, label="test loss")
    ax.set_xlabel("Epochs")
    ax.set_ylabel("cross-entropy loss")
    ax.set_title("Training and Test Loss")
    ax.legend() # makes a legend for multiple lines on the same plot
    fig.savefig("data/figures/loss_plot.png", dpi=150, bbox_inches="tight")
    # plt.show() # Will be called outside of this function


# Helper functions for saving and loading models
def _saveModel(model, path):
    torch.save(model.state_dict(), path)
    print(f"Saved PyTorch Model State to {path}")

def _loadModel(model: RNN | LSTM | GRU, path: Path, device: str = "mps") -> RNN | LSTM | GRU:
    model.load_state_dict(torch.load(path, weights_only=True))
    model.to(device)
    model.eval()
    print(f"Loaded PyTorch Model State from {path}")
    return model

@lru_cache(maxsize=None)          # the same 50,000 reviews are tokenized by every experiment, so do it once
def tokenize(text):
    text = re.sub(r"<br\s*/?>", " ", text.lower())   # IMDB reviews contain <br /> tags
    return re.findall(r"[a-z']+", text)

def buildVocab(examples, vocab_size=VOCAB_SIZE) -> dict:
    counts = Counter()
    common = []
    vocabdict = {}

    for example in examples:
        tokens = tokenize(example['text'])
        for token in tokens:
            counts[token] += 1
    
    # reserve 0=<pad>, 1=<unk>
    mostcommonCounts = counts.most_common(vocab_size - 2)
    for w, _ in mostcommonCounts:
        common.append(w)

    for i, w in enumerate(common):
            vocabdict[w] = i +2                                 # +2 because 0 and 1 are taken by <pad> and <unk>

    return vocabdict

def encode(text, vocab, max_len=MAX_LEN):
    ids = []
    tokenized = tokenize(text)
    for t in tokenized:
        ids.append(vocab.get(t, UNK))
    # ---
    ids = ids[:max_len]                                            # truncate
    padding = [PAD] * (max_len - len(ids))                         # how many pads are needed
    return padding + ids                                           # left-pad

def toDataLoader(examples, vocab, shuffle: bool =False, max_len: int = MAX_LEN):

    # --- texts: list of dicts -> list of padded int lists -> tensor
    texts = []
    for example in examples:
        texts.append(encode(example['text'], vocab, max_len))
    textTensors = torch.tensor(texts,dtype=torch.long)

    # --- labels: 'pos' -> 1.0, 'neg' -> 0.0
    labels = []
    for example in examples:
        if example['sentiment'] == 'pos':
            labels.append(1.0)
        else:
            labels.append(0.0) 
    labelTensors = torch.tensor(labels, dtype=torch.float32)
    # ---

    dataset = TensorDataset(textTensors, labelTensors)
    data = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)
    return data

@lru_cache(maxsize=None)          # reading 25,000 files per split once is enough
def loadDataset(trainOrtest: bool = False):
    from torchnlp.datasets import imdb_dataset
    # Load the IMDB dataset for training then prints some examples
    listOfDicts=[{}]

    if trainOrtest:
        listOfDicts = imdb_dataset(directory=str(DATA_DIR), train=True)
    else:
        listOfDicts = imdb_dataset(directory=str(DATA_DIR), test=True)
    
    # print(dictionaries[0:2])
    """format of each listOfDicts[i] is list containing i dictionaries
    {
          'text': 'For a movie that gets no respect there sure are a lot of memorable quotes...',
          'sentiment': 'pos'
        }
    """
    return listOfDicts

def prepareData(data: bool = False, vocab_size: int = VOCAB_SIZE, max_len: int = MAX_LEN):
    """prepareData
    This is the main data pipeline.
    Load the data apply the steps below and return the tokenized version
        Tokenize the text, 
        - (optional) remove stop words and punctuation 
        - convert tokens to integer sequences using a vocabulary, 
        - pad sequences to the same length.

    Keyword arguments:
    data -- to prepare train or test data
    Return: should return the DataLoader
    """
    train = loadDataset(True)
    test = loadDataset(False)

    # convert tokens to integer sequences using a vocabulary
    # pad sequences to the same length
    vocab = buildVocab(train, vocab_size)            # build from TRAIN only, reuse for test

    # Apply batch_size and shuffle them
    traindata = toDataLoader(train, vocab, True, max_len)
    testdata = toDataLoader(test, vocab, False, max_len)

    return traindata, testdata, vocab

def initializeModel(model_cls: type[RNN | LSTM | GRU], vocab_size: int = VOCAB_SIZE, embedding_dim: int = EMBEDDING_DIM,
                    pretrained=None, freeze: bool = False):
    """
    for all three models, initializeModel will need to take the class as a parameter
    
    Keyword arguments:
    model_cls -- one of the three nn.Module implemented (RNN, LSTM, GRU)
    Return: return_description
    """
    
    # Set the correct hardware
    device = get_device()

    # Initialize Model, Loss, and Optimizer
    # model = RNN(VOCAB_SIZE, EMBEDDING_DIM, HIDDEN_DIM).to(device)
    model = model_cls(vocab_size, embedding_dim, HIDDEN_DIM, pretrained=pretrained, freeze=freeze).to(device)

    # criterion = nn.BCEWithLogitsLoss()
    criterion = nn.BCELoss()
    optimizer = optim.Adam([p for p in model.parameters() if p.requires_grad], lr=0.001)   # a frozen embedding has nothing to update

    return model, device, criterion, optimizer

def test(dataloader, model, loss_fn, device):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0.0, 0
    with torch.no_grad():
        for X, y in dataloader:
            X, y = X.to(device), y.to(device)
            pred = model(X)
            test_loss += loss_fn(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
    test_loss /= num_batches
    correct /= size
    print(f"Test:  accuracy {100 * correct:>5.1f}%  avg loss {test_loss:>8f}")
    return correct, test_loss

def trainingLoop(model_cls: type[RNN | LSTM | GRU]):
    """sumary_line
    
    list of dicts → (texts, labels) as tensors → TensorDataset → DataLoader → iterate in batches

    fit() (model_eval.py) runs the epochs: it trains, scores the test loader once after every
    epoch and redraws the loss / accuracy curves live. The curves are also saved to
    data/figures/<run_name>_curves.png.

    Keyword arguments:
    model_cls -- the type of the model that we want to train
    Return: model, test_loader, device, criterion
    """
    torch.manual_seed(SEED)
    train_loader, test_loader, vocab = prepareData()
    # ---RNN, LSTM, GRU ---
    model, device, criterion, optimizer = initializeModel(model_cls)

    # Training Loop (BCELoss on the sigmoid output, same loss for training and the test curve)
    fit(model, train_loader, test_loader, criterion, optimizer, device, EPOCHS,
        run_name=f"{DOC_FIGS_NAME}_{model_cls.__name__}")

    # Return model, test_loader, device and the loss function used for evaluation
    return model, test_loader, device, criterion


        





def evaluateModel(model: RNN | LSTM | GRU, test_loader: DataLoader, device: str):
    """evaluateModel
        
        Evaluate the model on the test set.
        Reports accuracy, confusion matrix, precision, recall and F1 (positive class = 'pos' = 1).
        Returns the metrics as a dict so Problem1 can compare models.

        Evaluate the model on the test set
        Report: accuracy, confusion matrix, precision, recall, and F1 score

        Perplexity:
            We use perplexity as a metric to evaluate the performance of our RNN/LSTM model for sentiment analysis.
            perplexity of sequence X:
            - Perplexity = 1: Perfect model (always predicts the right token with probability 1)
            - Perplexity = ∞ (infinity): Worst case (assigns probability 0 to true tokens)
            - Perplexity = |vocabulary| (size of vocabulary): Baseline (uniform distribution over all words)
            - Lower perplexity = better model


        wrap it in model.eval() and with torch.no_grad(): 
        Threshold the output with (model(x).squeeze(1) > 0.5).float() to get 0/1 predictions.

    Keyword arguments:
    argument -- description
    Return: return_description
    """
    model.eval()                                  # inference mode (apperently)
    tp = 0
    tn = 0
    fp = 0
    fn = 0

    # torch.inference_mode()
    # torch.enable_grad()
    """
    counting tp/tn/fp/fn per batch then compute the metrices once at the end
        saves my sanity and memory   
    """
    with torch.no_grad():                         # no gradients needed, saves time and memory
        correct = 0
        total = 0
        for batchText, batchLabels in test_loader:
            batchText = batchText.to(device)
            batchLabels = batchLabels.to(device)

            probs = model(batchText).squeeze(1)  # [B, 1] -> [B], values in (0, 1)
            preds = (probs > 0.5).float()         # threshold -> hard 0.0 / 1.0

            
            tp += ((preds == 1) & (batchLabels == 1)).sum().item()
            tn += ((preds == 0) & (batchLabels == 0)).sum().item()
            fp += ((preds == 1) & (batchLabels == 0)).sum().item()
            fn += ((preds == 0) & (batchLabels == 1)).sum().item()

            # ---
            # Add an additional dimension for the sequence length
            batchText2 = batchText.unsqueeze(1)
            outputs = model(batchText2)
            predicted = (torch.sigmoid(outputs.squeeze()) > 0.5).float()
            total += batchLabels.size(0)
            correct += (predicted == batchLabels).sum().item()
            # ---
        # ---
        accuracy = correct / total
        print(f'Acuracy: {100*accuracy:.4f} %')
        # ---
    
    total     = tp + tn + fp + fn
    accuracy  = (tp + tn) / total
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall    = tp / (tp + fn) if (tp + fn) else 0.0
    f1        = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0

    modelname = type(model).__name__

    fancyString = f"""
        --- {modelname} test results ---
            Accuracy  : {accuracy:.4f}
            Precision : {precision:.4f}
            Recall    : {recall:.4f}
            F1 score  : {f1:.4f}

            Confusion matrix (rows = actual, cols = predicted):
                        neg   |   pos
                neg   {tn:6d} | {fp:6d}
                pos   {fn:6d} | {tp:6d}
    """
    
    print(fancyString)
    fancydict = {
                "model": modelname, 
                "accuracy": accuracy, "precision": precision,
                "recall": recall, "f1": f1, 
                "confusion_matrix": [[tn, fp], [fn, tp]]
    }
    
    return fancydict

def SentimentAnalysis(model_cls: type[RNN | LSTM | GRU]):
    """SentimentAnalysis
        1. Data Preperation
        2. Model architecture
        3. Train Model
        4. Evaluate Model
        5. Repeat for LSTM and GRU, then compare all (RNN, LSTM, GRU)
    
    Keyword arguments:
    model -- RNN or LSTM or GRU
    Return: return_description
    """
    # 1-3. Data preparation, model architecture and training all happen inside trainingLoop
    model, test_loader, device, criterion = trainingLoop(model_cls)

    path = MODEL_PATH
    _saveModel(model, path)

    # 4. Evaluate Model: prints the metrics, draws + saves the confusion matrix and the
    #    accuracy / precision / recall / F1 bars, and returns the metrics dict so Problem1 can compare models
    return evaluateAndPlot(model, test_loader, criterion, device,
                           run_name=f"{DOC_FIGS_NAME}_{model_cls.__name__}", class_names=["neg", "pos"])

# ---Problem 1---
def Problem1():
    """
    Use the IMDB dataset (available via `torchtext` or `tensorflow_datasets`) 
        — 25,000 training reviews, 25,000 test reviews (binary: positive/negative).

    1. Tokenize the text, remove stop words and punctuation (optional), 
        convert tokens to integer sequences using a vocabulary, and pad sequences to the same length.
    2. Build a simple RNN model using a framework of your choice (i.e., `PyTorch`, `TensorFlow`, or `Keras`). 
        Your model architecture must include an embedding layer, an RNN layer, and a fully connected output layer with sigmoid activation.
    3. Train the model using the training set and log the training process using binary cross-entropy loss and apply the Adam optimizer. 
        Train the model for a fixed number of epochs (5-10) and record the loss and accuracy.
    4. Evaluate the model on the test set and report the accuracy, confusion matrix, precision, recall, and F1 score.
    5. Replace RNN with LSTM and GRU and compare performance with different embedding sizes and sequence lengths. 
        Also, repeat the experiment using a pre-trained embedding (GloVe) and compare the performance.

    For Problem1 hidden[-1], summarizes the whole sequence

    TODO: Each trainingLoop call re-reads and re-tokenizes all 50,000 files, so Problem1 does it three times. Its fine for now. Later
            could call prepareData() once in Problem1 and pass the loaders down as arguments.
    
    Keyword arguments:
    argument -- description
    Return: return_description
    """
    results = []
    for cls in (RNN, LSTM, GRU):
        results.append(SentimentAnalysis(cls))

    # Comparison table, printed once after all three models have been trained and evaluated
    print(f"{'Model':<6} | {'Acc':>7} | {'Prec':>7} | {'Rec':>7} | {'F1':>7}")
    for result in results:
        print(f"{result['model']:<6} | {result['accuracy']:7.4f} | {result['precision']:7.4f} | {result['recall']:7.4f} | {result['f1']:7.4f}")

    # One blocking call for every figure: the curves and the evaluation chart of each model
    plt.show()


# ---Problem 1, task 5: embedding sizes, sequence lengths and pre-trained (GloVe) embeddings---

def loadGlove(vocab: dict, vocab_size: int, dim: int) -> torch.Tensor:
    """[vocab_size, dim] matrix whose row i is the GloVe vector of the word with id i.

    Words GloVe has no vector for (and <unk>) get a small random vector, <pad> stays all zeros.
    Needs data/glove/glove.6B.<dim>d.txt (dim = 50, 100, 200 or 300).
    """
    path = GLOVE_DIR / f"glove.6B.{dim}d.txt"
    weights = torch.randn(vocab_size, dim) * 0.1
    weights[PAD] = 0.0
    found = 0
    with open(path, encoding="utf-8") as f:
        for line in f:
            word, _, rest = line.partition(" ")
            idx = vocab.get(word)                           # only parse the lines for words we use
            if idx is not None:
                weights[idx] = torch.tensor([float(x) for x in rest.split()])
                found += 1
    print(f"GloVe {dim}d: found a vector for {found} of {len(vocab)} vocabulary words")
    return weights


def runExperiment(model_cls: type[RNN | LSTM | GRU], tag: str, vocab_size: int = VOCAB_SIZE,
                  embedding_dim: int = EMBEDDING_DIM, max_len: int = MAX_LEN,
                  glove: bool = False, freeze: bool = False, seed: int = SEED) -> dict:
    """Train + evaluate one model with one setting. Same seed, optimizer, loss and epochs as Problem1,
    only the setting changes. Curves and history go to data/figures/sweep/, no window is opened."""
    torch.manual_seed(seed)
    train_loader, test_loader, vocab = prepareData(vocab_size=vocab_size, max_len=max_len)
    pretrained = loadGlove(vocab, vocab_size, embedding_dim) if glove else None
    model, device, criterion, optimizer = initializeModel(model_cls, vocab_size, embedding_dim, pretrained, freeze)

    name = f"{model_cls.__name__}_{tag}"
    start = time.time()
    history = fit(model, train_loader, test_loader, criterion, optimizer, device, EPOCHS,
                  run_name=f"{DOC_FIGS_NAME}_{name}", live=False, out_dir=SWEEP_DIR)
    seconds = time.time() - start

    r = evaluateLoader(model, test_loader, criterion, device)
    best = max(range(EPOCHS), key=lambda i: history["val_acc"][i])
    print(f"{name}: acc {r['accuracy']:.4f}  prec {r['precision']:.4f}  rec {r['recall']:.4f}  f1 {r['f1']:.4f}  ({seconds:.0f}s)")
    return {"name": name, "model": model_cls.__name__, "tag": tag, "seed": seed, "vocab_size": vocab_size,
            "embedding_dim": embedding_dim, "max_len": max_len,
            "embedding": ("GloVe frozen" if freeze else "GloVe fine-tuned") if glove else "random",
            "accuracy": r["accuracy"], "precision": r["precision"], "recall": r["recall"], "f1": r["f1"],
            "confusion_matrix": r["confusion_matrix"], "test_loss": r["loss"], "seconds": seconds,
            "best_epoch": best + 1, "best_val_acc": history["val_acc"][best],
            "train_acc": history["train_acc"][-1], "history": history}


# (tag, vocab_size, embedding_dim, max_len, glove, freeze). The first rows change one thing at a time
# from the Problem 1 setting (vocab 1000, 100 dims, length 200); the rest add GloVe.
SETTINGS = [
    ("base",             1000, 100, 200, False, False),
    ("vocab10k",        10000, 100, 200, False, False),
    ("vocab10k_glove_frozen", 10000, 100, 200, True, True),
    ("vocab10k_glove_tuned",  10000, 100, 200, True, False),
    ("dim50",            1000,  50, 200, False, False),
    ("dim200",           1000, 200, 200, False, False),
    ("len100",           1000, 100, 100, False, False),
    ("len400",           1000, 100, 400, False, False),
    ("glove_frozen",     1000, 100, 200, True, True),
    ("glove_tuned",      1000, 100, 200, True, False),
    ("vocab10k_glove_tuned_d50",  10000,  50, 200, True, False),
    ("vocab10k_glove_tuned_d200", 10000, 200, 200, True, False),
]
SEED_RUNS = (1, 2)      # the base setting is repeated with these seeds to see how much a result moves by chance


def loadSweepResults() -> list:
    """Every finished run, from data/figures/sweep/results_<model>.json."""
    results = []
    for path in sorted(SWEEP_DIR.glob("results_*.json")):
        results += json.loads(path.read_text())
    order = {s[0]: i for i, s in enumerate(SETTINGS)}
    models = {"RNN": 0, "LSTM": 1, "GRU": 2}
    return sorted(results, key=lambda r: (order.get(r["tag"], 99), r["tag"], models[r["model"]]))


def Experiments(models=(RNN, LSTM, GRU), extras_only: bool = False):
    """Task 5: RNN, LSTM and GRU across embedding sizes, sequence lengths, vocabulary sizes and GloVe.

    Each model keeps its own results_<model>.json (so LSTM and GRU can train in two processes at
    once), written after every run. Runs already in the file are skipped, so an interrupted
    sweep can simply be started again. extras_only runs just the last two settings and the repeated
    seeds, into its own results file, so a slow model can be shared between two processes.
    """
    SWEEP_DIR.mkdir(parents=True, exist_ok=True)
    for cls in models:
        path = SWEEP_DIR / f"results_{cls.__name__}{'_extra' if extras_only else ''}.json"
        results = json.loads(path.read_text()) if path.exists() else []
        done = {r["name"] for r in results}

        for tag, vocab_size, dim, max_len, glove, freeze in (SETTINGS[-2:] if extras_only else SETTINGS):
            if f"{cls.__name__}_{tag}" in done:
                continue
            results.append(runExperiment(cls, tag, vocab_size, dim, max_len, glove, freeze))
            path.write_text(json.dumps(results, indent=1))

        for seed in SEED_RUNS:
            if f"{cls.__name__}_base_seed{seed}" in done:
                continue
            results.append(runExperiment(cls, f"base_seed{seed}", seed=seed))
            path.write_text(json.dumps(results, indent=1))


def sweepSummary():
    """Table + chart of everything the sweep has finished so far."""
    results = loadSweepResults()
    printSweep(results)
    plotSweep(results)


def printSweep(results: list):
    header = f"{'Run':<28} {'Embedding':<17} {'Vocab':>5} {'Dim':>4} {'Len':>4} | {'Acc':>6} {'Prec':>6} {'Rec':>6} {'F1':>6} | {'Best ep':>7}"
    print("\n" + header)
    for r in results:
        print(f"{r['name']:<28} {r['embedding']:<17} {r['vocab_size']:>5} {r['embedding_dim']:>4} {r['max_len']:>4} | "
              f"{r['accuracy']:6.4f} {r['precision']:6.4f} {r['recall']:6.4f} {r['f1']:6.4f} | {r['best_epoch']:>7}")


def plotSweep(results: list):
    """Test accuracy of every setting, LSTM next to GRU -> data/figures/sweep/summary.png"""
    tags = [s[0] for s in SETTINGS if any(r["tag"] == s[0] for r in results)]
    fig, ax = plt.subplots(figsize=(13, 4.5))
    width = 0.27
    for k, cls in enumerate(("RNN", "LSTM", "GRU")):
        accs = [next((r["accuracy"] for r in results if r["tag"] == t and r["model"] == cls), 0) for t in tags]
        bars = ax.bar([i + (k - 1) * width for i in range(len(tags))], accs, width, label=cls)
        ax.bar_label(bars, labels=[f"{a:.0%}" for a in accs], fontsize=6, padding=2)
    ax.set_xticks(range(len(tags)), tags, rotation=30, ha="right")
    ax.set_ylim(0.4, 1.0)
    ax.set_ylabel("test accuracy")
    ax.set_title("Problem 1 task 5: embedding size, sequence length, vocabulary and GloVe")
    ax.legend(ncol=3, loc="upper left")
    fig.savefig(SWEEP_DIR / "summary.png", dpi=150, bbox_inches="tight")


def example():
    """Source code for torchnlp.datasets.imdb
        https://pytorchnlp.readthedocs.io/en/latest/_modules/torchnlp/datasets/imdb.html
        
        Prerequisite:pip3 install pytorch-nlp

    """

    def imdb_dataset(directory='data/', train=False, test=False, train_directory='train', test_directory='test',extracted_name='aclImdb',
                    check_files=['aclImdb/README'], url='http://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz', sentiments=['pos', 'neg']):
        """
        Load the IMDB dataset (Large Movie Review Dataset v1.0).

        This is a dataset for binary sentiment classification containing substantially more data than
        previous benchmark datasets. Provided a set of 25,000 highly polar movie reviews for
        training, and 25,000 for testing. There is additional unlabeled data for use as well. Raw text
        and already processed bag of words formats are provided.

        Note:
            The order examples are returned is not guaranteed due to ``iglob``.

        Reference: http://ai.stanford.edu/~amaas/data/sentiment/

        Args:
            directory (str, optional): Directory to cache the dataset.
            train (bool, optional): If to load the training split of the dataset.
            test (bool, optional): If to load the test split of the dataset.
            train_directory (str, optional): The directory of the training split.
            test_directory (str, optional): The directory of the test split.
            extracted_name (str, optional): Name of the extracted dataset directory.
            check_files (str, optional): Check if these files exist, then this download was successful.
            url (str, optional): URL of the dataset ``tar.gz`` file.
            sentiments (list of str, optional): Sentiments to load from the dataset.

        Returns:
            :class:`tuple` of :class:`iterable` or :class:`iterable`:
            Returns between one and all dataset splits (train, dev and test) depending on if their
            respective boolean argument is ``True``.

        Example:
            >>> from torchnlp.datasets import imdb_dataset  # doctest: +SKIP
            >>> train = imdb_dataset(train=True)  # doctest: +SKIP
            >>> train[0:2]  # doctest: +SKIP
            [{
            'text': 'For a movie that gets no respect there sure are a lot of memorable quotes...',
            'sentiment': 'pos'
            }, {
            'text': 'Bizarre horror movie filled with famous faces but stolen by Cristina Raines...',
            'sentiment': 'pos'
            }]
        """
        download_file_maybe_extract(url=url, directory=directory, check_files=check_files)

        ret = []
        splits = [
            dir_ for (requested, dir_) in [(train, train_directory), (test, test_directory)]
            if requested
        ]
        for split_directory in splits:
            full_path = os.path.join(directory, extracted_name, split_directory)
            examples = []
            for sentiment in sentiments:
                for filename in glob.iglob(os.path.join(full_path, sentiment, '*.txt')):
                    with open(filename, 'r', encoding="utf-8") as f:
                        text = f.readline()
                    examples.append({
                        'text': text,
                        'sentiment': sentiment,
                    })
            ret.append(examples)

        if len(ret) == 1:
            return ret[0]
        else:
            return tuple(ret)

    imdb_dataset(directory=str(DATA_DIR), train=True)


def main():
    parser = argparse.ArgumentParser(description="COMP 457 Problem 1: sentiment analysis on IMDb")
    parser.add_argument("--sweep", nargs="*", choices=["RNN", "LSTM", "GRU"], metavar="MODEL",
                        help="task 5: LSTM/GRU across embedding sizes, sequence lengths, vocabulary sizes and GloVe "
                             "(--sweep LSTM or --sweep GRU runs just one, so two terminals can share the work)")
    parser.add_argument("--extras-only", action="store_true", help="with --sweep: only the GloVe-size runs and repeated seeds")
    parser.add_argument("--summary", action="store_true", help="print the sweep table and draw the sweep chart")
    args = parser.parse_args()
    if args.summary:
        sweepSummary()
    elif args.sweep is not None:
        Experiments(tuple({"RNN": RNN, "LSTM": LSTM, "GRU": GRU}[m] for m in args.sweep) if args.sweep else (RNN, LSTM, GRU), args.extras_only)
    else:
        Problem1()

if __name__ == "__main__":
    main()